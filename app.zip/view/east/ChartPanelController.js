/**
* North Controller
*/
Ext.define('KRF_DEV.view.east.ChartPanelController', {
	extend: 'Ext.app.ViewController',

	alias: 'controller.chartPanelController',
	/*
	control: {
		'#btnShowSearchWindow': {
			el: {
				click: 'onShowSearchWindow'
			}
		}
	},
	
	onShowSearchWindow: function(){
		
		var dateWinCtl = Ext.getCmp("datePanel1");
		
		if(dateWinCtl == undefined)
			dateWinCtl = Ext.create("KRF_DEV.view.east.ChartPanelDate");
		
		dateWinCtl.show();
		
	}*/
});